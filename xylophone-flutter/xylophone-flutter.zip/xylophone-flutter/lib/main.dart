import 'package:flutter/material.dart';

void main() => runApp(XylophoneApp());

class XylophoneApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.lightBlue,
        body: SafeArea(
          child: FlatButton(
            onPressed: () {

            },
            child: Center(
              child: Text('click me!'),
            ),
          ),
        ),
      ),
    );
  }
}
